<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class jobs_list extends Model
{
     protected $table="jobs_list";
    public $timestamps = false; 
}
