<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class candidate_persnal_info extends Model
{
    protected $table="candidate_persnal_info";
    public $timestamps = false; 
}
