<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class users_list extends Model
{
    protected $table="users_list";
    public $timestamps = false; 
}


?>