<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users_list;
use App\Models\programs;


class UserProfilingController extends Controller
{
	
	
		 public function signup(Request $input)
    { 
        if(isset($input->verify))
        {
               
               
        $rec_edit  = users_list::where('shufl_id',$input->verify)->first();
        $rec_edit->status = "Active";
        $rec_edit->save();
               	$input->session()->flash('success_message', 'Your account has been activated now you can login');
               		return redirect('account');
        }
        return view('users.signup');
    }
	
	
		 public function account(Request $input)
    { 
        if(isset($input->verify))
        {
               
               
        $rec_edit  = users_list::where('shufl_id',$input->verify)->first();
        $rec_edit->status = "Active";
        $rec_edit->save();
               	$input->session()->flash('success_message', 'Your account has been activated now you can login');
               		return redirect('account');
        }
        return view('users.account');
    }
	
	
	
	
		 public function account_working(Request $input)
    { 
	
	 if($input->type =="4")
			{
	
	       $Old_pass    = substr(md5(md5(md5(md5(md5($input->Old_pass))))),0,8); 
			$New_pass    = substr(md5(md5(md5(md5(md5($input->New_pass))))),0,8); 
			$Confirm     = substr(md5(md5(md5(md5(md5($input->Confirm))))),0,8); 
			
			if($New_pass != $Confirm)
			{
			$input->session()->flash('Error_message', 'New password and confirm password must be same');
            return redirect('user-password');
			}
			
			$check_old  = users_list::where('email',session()->get('user_email'))->where('Password',$Old_pass)->count();
		
		if($check_old>0)
		{
		$password_change	= users_list::where('email',session()->get('user_email'))->first();
		$password_change->Password  = $New_pass;
		$password_change->save();
		$input->session()->flash('success_message', 'Account password has been changed successfully!');
		}else
		{
			      $input->session()->flash('Error_message', 'Old password is not valid');
                
		}
		
		
		
		
        return redirect('user-password');
	
	
	} else if($input->type =="3")
			{
					$recd  =  users_list::find(session()->get('user_id'));
		
	          $input->session()->flash('success_message', 'New user  created  successfully!');
		
			$recd->name  =  $input->name ;
			$recd->whatsapp  =  $input->whatsapp ;
			$recd->Address  =  $input->Address ;
			$recd->City  =  $input->City ;
			$recd->Country  =  $input->Country ;
			$recd->dob  =  $input->dob ;
			$recd->save();
			
			$check_recd  =  users_list::find(session()->get('user_id'));
			 $input->session()->put('user_name',$check_recd->name);
           $input->session()->put('user_number',$check_recd->number);
           $input->session()->put('user_whatsapp',$check_recd->whatsapp);
           $input->session()->put('user_email',$check_recd->email);
		   $input->session()->put('user_img',$check_recd->img);
           $input->session()->put('user_Address',$check_recd->Address);
		   $input->session()->put('user_City',$check_recd->City);
           $input->session()->put('user_Country',$check_recd->Country);
		   $input->session()->put('user_dob',$check_recd->dob);
			
		    return redirect('user-profile');
		
			}else if($input->type =="1")
			{
			$Password =	substr(md5(md5(md5(md5(md5($input->Password))))),0,8);  
			$check_recd  = users_list::where('email',$input->email)->where('Password',$Password)->first();
            	if($check_recd !="")
			{
			    
			    if($check_recd->status =="Pending")
			{
				$input->session()->flash('Error_message', 'Sorry your account still not verified.Please check your email');
				
						$email_to = $input->email; 
$email_from = 'noreply@studynortherncyprus.com'; //website email address
$webiste_name = 'Studynortherncyprus';
$subject =  "Welcome to Studynortherncyprus";
$message = '
<center>


 <h1 >Welcome to Studynortherncyprus  </h1>
 <p >Hi! '.$check_recd->name.' Your account still not verified please click bellow link to verify your email <br><br>
               Verification Link: <a href="https://studynortherncyprus.com/snc/account?verify='.$check_recd->shufl_id.'"> Verify Account</a> <br><br>
         </p>
</center>
 ';
   return $this->email("account",$email_to, $webiste_name, $email_from, $subject, $message);
				
				
			} 
			    
			    
				  $input->session()->put('user_id',$check_recd->id);
           $input->session()->put('user_name',$check_recd->name);
           $input->session()->put('user_number',$check_recd->number);
           $input->session()->put('user_whatsapp',$check_recd->whatsapp);
           $input->session()->put('user_email',$check_recd->email);
		   $input->session()->put('user_img',$check_recd->img);
           $input->session()->put('user_Address',$check_recd->Address);
		   $input->session()->put('user_City',$check_recd->City);
           $input->session()->put('user_Country',$check_recd->Country);
		   $input->session()->put('user_dob',$check_recd->dob);
           $input->session()->put('user_shufl_id',$check_recd->shufl_id);
		   $input->session()->flash('success_message', 'Welcome back.');
				
				
				
				return redirect($input->redirect_link);
			}else if($input->type =="0")
			{
				$input->session()->flash('Error_message', 'Sorry invalid login details.');
				return redirect('account');
			} 
			 
			 
			 
			}{
			
			
			
			$check_recd  = users_list::where('email',$input->email)->orwhere('whatsapp',$input->whatsapp)->first();
			if($check_recd !="")
			{$input->session()->flash('Error_message', 'this user already exists.');
				return redirect('account');
			}
			
		$recd  =  new users_list;
		$sufll =   substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"),0,22).time();
	$input->session()->flash('success_message', 'New user  created  successfully!');
		
		$recd->name  =  $input->name ;
		$recd->whatsapp  =  $input->whatsapp ;
		$recd->email  =  $input->email ;
		$recd->Password  = substr(md5(md5(md5(md5(md5($input->Password))))),0,8);  
		
		$recd->joining_date  =  Date('Y-m-d') ;
		$recd->status  =  "Pending";
		$recd->shufl_id  =  $sufll;
		$recd->img  =  "dummy.png";
		$recd->save();
		
		$email_to = $input->email; 
$email_from = 'noreply@studynortherncyprus.com'; //website email address
$webiste_name = 'Studynortherncyprus';
$subject =  "Welcome to Studynortherncyprus";
$message = '
<center>


<h1 >Welcome to Studynortherncyprus  </h1>
 <p >Hi! '.$input->name.' your account has been created at Studynortherncyprus please click bellow link to verify your email <br><br>
               Verification Link: <a href="https://studynortherncyprus.com/snc/account?verify='.$sufll.'"> Verify Account</a> <br><br>
         </p>
</center>
 ';
   return $this->email("account",$email_to, $webiste_name, $email_from, $subject, $message);
		
		
		
		
			}
        return redirect('account');
		
    }
	
	  function email($redirect,$to, $from_name, $from_email, $subject, $message, $contentType = "html", $to_cc = null, $to_bcc = null)
{
  $contentType = "html";
    $headers = "From: \"$from_name\" <" . $from_email . ">\r\n";
    $headers .= "Reply-To: \"$from_name\" <$from_email>\r\n";
    if ($to_cc != null) {
        $headers .= "CC: $to_cc\r\n";
    }
    if ($to_bcc != null) {
        $headers .= "BCC: $to_bcc\r\n";
    }
    $headers .= "X-Sender: \"$from_name\" <$from_email>\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    if ($contentType == "plain")
        $headers .= 'Content-type: text/plain;' . "\r\n";
    else
        $headers .= 'Content-type: text/html;' . "\r\n";
    $headers .= "X-Priority: 3\n";
    
   $retval =  mail($to, $subject, $message, $headers);
  
    
    
         if( $retval == true ) {
         // session()->flash('success_message','Thanks! Message Received.');
          return redirect($redirect);
        
      }else{
      // session()->flash('Error_message','Some thing wrong.please try again');
          return redirect($redirect);
    }
}
	
      public function user_profile()
    { 
        return view('users.user_profile');
    }
	
	 public function user_password()
    { 
        return view('users.user_password');
    }
	
}
