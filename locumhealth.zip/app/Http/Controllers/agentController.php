<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\candidate_persnal_info;
use App\Models\applications;
use App\Models\miscellaneous;
use App\Models\universities;
use App\Models\programs;
use App\Models\agents;
use App\Models\admin;

class agentController extends Controller
{
   
   
    public function partner(Request $input)
    { 
        return view('users.partner');
    }
   
   
    public function become_agent(Request $input)
    { 
        return view('users.become_agent');
    }
	
	
	 public function save_agent(Request $input)
    { 
	
	
			$sufll =   substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"),0,8);

	
        $admin  =  new admin;
		$admin->first_name  =  $input->first_name ;
		$admin->phone  =  $input->phone ;
		$admin->username  =  $input->email ;
		$admin->email  =  $input->email ;
		$admin->first_name  =  $input->first_name ;
		$admin->img  =  "dummy.png";
		$admin->role  =  "Agent";
		$admin->status  =  "Pending";
		$admin->password  = substr(md5(md5(md5(md5(md5("85rfe5786"))))),0,8);  
		$admin->usr_id  = $sufll; 
		$admin->save();
		
		
		

		
		
		$recd  =  new agents;
	$input->session()->flash('success_message', 'Your request has been received. our team will review your information and will contact you soon.');
		
		$recd->rec_id  =  $admin->id ;
		$recd->Date_Of_Establishment  =  $input->Date_Of_Establishment ;
		$recd->NTN  =  $input->NTN ;
		$recd->CNIC  =  $input->CNIC ;
		$recd->Address  =  $input->Address ;
		$recd->Countries  =  $input->Countries ;
		$recd->Average_Student  =  $input->Average_Student ;
		$recd->CEO_Name  =  $input->CEO_Name ;
		$recd->Mobile_Whatsapp  =  $input->Mobile_Whatsapp ;
		$recd->joining_date  =  Date('Y-m-d') ;
		$recd->shufl_id  =  $sufll;
		
		   if($input->hasfile('doc_01')){
            $selected_pic = $input->file('doc_01');
            
            $extension = $selected_pic->getClientOriginalExtension();
            $doc_01 =  substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"),0,12).time().'.'.$extension;
            $recd->doc_01 =  $doc_01 ;
            $selected_pic->move('upload/',$doc_01);
           
           } 
		  
		   
		      if($input->hasfile('doc_02')){
            $selected_pic = $input->file('doc_02');
            
            $extension = $selected_pic->getClientOriginalExtension();
            $doc_02 =  substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"),0,12).time().'.'.$extension;
            $recd->doc_02 =  $doc_02 ;
            $selected_pic->move('upload/',$doc_02);
           } 
		
		$recd->save();
		
		
		
		
		$email_to = $input->email ;
$email_from = 'noreply@studynortherncyprus.com'; //website email address
$webiste_name = 'Studynortherncyprus';
$subject =  "Welcome to Studynortherncyprus";
$message = '
<center>


<h1 >Welcome to Studynortherncyprus  </h1>
 <p >Hi! '.$input->first_name.' Your request has been received. our team will review your information and will contact you soon. </a> <br><br>
         </p>
</center>
 ';
		
		
		
		 return $this->email("become-agent",$email_to, $webiste_name, $email_from, $subject, $message);
		//return redirect('become-agent');
		
		
    }
   
   
   
   function email($redirect,$to, $from_name, $from_email, $subject, $message, $contentType = "html", $to_cc = null, $to_bcc = null)
{
  $contentType = "html";
    $headers = "From: \"$from_name\" <" . $from_email . ">\r\n";
    $headers .= "Reply-To: \"$from_name\" <$from_email>\r\n";
    if ($to_cc != null) {
        $headers .= "CC: $to_cc\r\n";
    }
    if ($to_bcc != null) {
        $headers .= "BCC: $to_bcc\r\n";
    }
    $headers .= "X-Sender: \"$from_name\" <$from_email>\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    if ($contentType == "plain")
        $headers .= 'Content-type: text/plain;' . "\r\n";
    else
        $headers .= 'Content-type: text/html;' . "\r\n";
    $headers .= "X-Priority: 3\n";
    
   $retval =  mail($to, $subject, $message, $headers);
  
    
    
         if( $retval == true ) {
         // session()->flash('success_message','Thanks! Message Received.');
          return redirect($redirect);
        
      }else{
      // session()->flash('Error_message','Some thing wrong.please try again');
          return redirect($redirect);
    }
}
   
}
