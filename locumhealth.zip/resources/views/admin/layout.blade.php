
 
  @include ('admin/include/head')

<body  >
          <div id="layout-wrapper">
         
            <div class="main-content">
       
           
    
@include ('admin/include/header')
  

 @section('mainarea')
    


  @show
  
  
  
   
    @include ('admin/include/footer')
  </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->
    
</body>


</html>