<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Study Northern Cyprus.
                            </div>
                            
                        </div>
                    </div>
                </footer>
				
				  <!-- JAVASCRIPT -->
				 
				  
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/js/plugins.js"></script>

        <!-- apexcharts -->
        <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
        
        <!-- Vector map-->
        <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
        <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>
        
        <!--Swiper slider js-->
        <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
        
        <script src="assets/libs/list.js/list.min.js"></script>
        
        <!-- Dashboard init -->
        <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
        
        <!-- App js -->
        <script src="assets/js/app.js"></script>
		
		 <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- apexcharts -->

    <!-- piecharts init -->
    <script src="assets/js/pages/apexcharts-pie.init.js"></script>

  <link href="assets/DataTables/datatables.min.css" rel="stylesheet">
 
<script src="assets/DataTables/datatables.min.js"></script>
<!-- ckeditor -->
    <script src="assets/libs/%40ckeditor/ckeditor5-build-classic/build/ckeditor.js"></script>

    <!-- init js -->
    <script src="assets/js/pages/form-editor.init.js"></script>

<script>
new DataTable('#example');

 </script>