  <!-- FOR EMPLOYEE START -->
            <div class="section-full p-t120 p-b120 twm-for-employee-9-area site-bg-white">
                <div class="container">
                    <div class="section-content">
                        <div class="twm-for-employee-9">
                            <div class="row">

                                <div class="col-lg-6 col-md-12">
                                    <div class="twm-explore-content-outer-3">

                                        <div class="twm-explore-content-3">
                                            
                                            <div class="twm-title-large">
                                                <h2>Refer a friend</h2>
                                                <p>Do you know of any qualified candidates seeking locum roles? We’re actively seeking top talent to join our team. Your referrals are invaluable to us, kindly refer a friend today and let’s create success stories together!
                                                </p>
                                            </div>
                                            <div class="twm-upload-file">
                                                <a href="#refer_friend" data-bs-toggle="modal"  class="site-button">Refer a friend </a>
                                            </div>
                                            
                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-12">
                                    <div class="twm-explore-content-outer-3">

                                        <div class="twm-explore-content-3">
                                            
                                            <div class="twm-title-large">
                                                <h2>Give feedback</h2>
                                                <p>Your feedback is invaluable to us! Whether you’re a satisfied client or a successful candidate, we’d love to hear about your experience. Please take a moment to share your thoughts—it helps us improve and provides valuable insights for others.
                                                </p>
                                            </div>
                                            <div class="twm-upload-file">
                                                <a href="contact" class="site-button">Leave feedback</a>
                                            </div>
                                            
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
            <!-- FOR EMPLOYEE END -->
  <?php 
  
   $miscellaneous = \App\Models\tb_posts::where('type','Testimonials')->get();
   
  
  ?>  
            <!-- TESTIMONIAL SECTION START -->
            <div class="section-full p-t120 p-b90 site-bg-light twm-testimonial-8-area">
                
                <div class="container">

                    <!-- TITLE START-->
                    <div class="section-head left wt-small-separator-outer">
                        <div class="section-head center wt-small-separator-outer">
                            <div class="wt-small-separator site-text-primary">
                               <div>Client Testimonials</div>                                
                            </div>
                            <h2 class="wt-title">Testimonials</h2>
                        </div>
                    </div>                  
                    <!-- TITLE END-->

                    <div class="section-content"> 
                        
                        <div class="owl-carousel twm-testimonial-8-carousel m-b30 owl-btn-bottom-center ">
                         @foreach($miscellaneous as $r_data)
                            <!-- COLUMNS 1 --> 
                            <div class="item ">
                                <div class="testimonials-v site-bg-white">
                                    <div class="twm-testi-media">
                                        <img src="upload/{{ $r_data->pic}}" alt="#">
                                    </div>
                                    <div class="testimonial-v-content">
                                        <div class="t-testimonial-top">
                                            <div class="t-quote"><i class="fa fa-quote-left"></i></div>
                                            <div class="t-rating">
                                                <span><i class="fa fa-star"></i></span>
                                                <span><i class="fa fa-star"></i></span>
                                                <span><i class="fa fa-star"></i></span>
                                                <span><i class="fa fa-star"></i></span>
                                                <span><i class="fa fa-star"></i></span>
                                            </div>
                                        </div>
                                        
                                        <div class="t-discription"><?php echo $r_data->desciption; ?>
                                        </div>

                                        <div class="twm-testi-detail">
                                            <div class="twm-testi-name">{{ $r_data->title}}</div>
                                            
                                        </div>
                                    </div>   
                                </div>
                            </div>
                           @endforeach
                            <!-- COLUMNS 2 --> 
                            
                            

                        </div>
                        
                    </div>                              
                </div>
                
            </div>
            <!-- TESTIMONIAL SECTION END -->